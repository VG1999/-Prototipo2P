﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaModelo
{
    class clsAplicativo
    {
        private int iCod_empleado;
        private int iPuesto;
        private int iDepartamento;
        private string sNombre;
        private float sSueldo;
        private int iEstado;

       




    }
}
